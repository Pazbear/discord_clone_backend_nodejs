use discord_clone;
insert into SERVER(name, host) values ("테스트5", 2);