use discord_clone;
select * from USER;
select * from SERVER where host = 2;