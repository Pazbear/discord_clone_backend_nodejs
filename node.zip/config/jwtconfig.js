module.exports = {
    secretKey : 'Pazbear12@',
    option : {
        algorithm : "HS256",
        expiresIn : "1h",
        issuer : "pazbear"
    }
}